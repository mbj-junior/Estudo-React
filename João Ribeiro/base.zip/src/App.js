import React from 'react';

class App extends React.Component{
  render(){
    return(
      <p>Olá</p>
    )
  }
}

export default App;
